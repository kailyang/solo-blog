title: ' 运行bookinfo示例'
date: '2019-11-20 23:51:17'
updated: '2019-11-20 23:51:17'
tags: [微服务, 服务网格, Istio]
permalink: /articles/2019/11/20/1574265076957.html
---
![](https://img.hacpai.com/bing/20191111.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

在Istio安装完成之后，为了检验istio，或者学习使用istio，可以尝试先运行istio自带的示例应用bookinfo。

### 部署bookinfo

参考官方文档：

* [https://istio.io/docs/examples/bookinfo/](https://istio.io/docs/examples/bookinfo/)
    

kubectl label namespace default istio-injection=enabled  
​  
kubectl apply -f samples/bookinfo/platform/kube/bookinfo.yaml  
​  
# 验证  
kubectl get services  
kubectl get pods  
# 检查一下pod，看istio的sidecar自动注入是否成功  
kubectl describe pod details-v1-65b966b497-clvzh

### 检验ingress ip 和 端口

安装 bookinfo 的 ingress gateway：

kubectl apply -f samples/bookinfo/networking/bookinfo-gateway.yaml  
​  
# 确认  
$ kubectl get gateway  
NAME                              AGE  
bookinfo-gateway                  31m  
httpbin-gateway                   19m

遵循指南建议，设置 `INGRESS_HOST` 和 `INGRESS_PORT` 变量以便访问 gateway。

具体做法见下一节，在完成之后回到这里继续。设置 GATEWAY_URL：

export GATEWAY_URL=$INGRESS_HOST:$INGRESS_PORT

验证 bookinfo 应用是否运行：

$ curl -o /dev/null -s -w "%{http_code}\n" http://${GATEWAY_URL}/productpage  
200

可以通过浏览器访问地址 `http://$GATEWAY_URL/productpage`

> 备注：GATEWAY_URL通常是 192.168.0.10:31380 这样的地址

### 检验ingress ip 和 端口

[https://istio.io/docs/tasks/traffic-management/ingress/#determining-the-ingress-ip-and-ports](https://istio.io/docs/tasks/traffic-management/ingress/#determining-the-ingress-ip-and-ports)

查看istio-ingressgateway：

$ kubectl get svc istio-ingressgateway -n istio-system  
NAME                   TYPE           CLUSTER-IP       EXTERNAL-IP   PORT(S)                                                                                                                   AGE  
istio-ingressgateway   LoadBalancer   10.109.191.143   <pending>     80:31380/TCP,443:31390/TCP,31400:31400/TCP,15011:30556/TCP,8060:31410/TCP,853:32282/TCP,15030:32127/TCP,15031:30924/TCP   52d

EXTERNAL-IP 为 ，说明没有外部负载均衡器。跳到 “Determining the ingress IP and ports when using a node port”

设置 ingress 端口：

export INGRESS_PORT=$(kubectl -n istio-system get service istio-ingressgateway -o jsonpath='{.spec.ports[?(@.name=="http2")].nodePort}')  
export SECURE_INGRESS_PORT=$(kubectl -n istio-system get service istio-ingressgateway -o jsonpath='{.spec.ports[?(@.name=="https")].nodePort}')

设置 ingress ip （Other environments）：

export INGRESS_HOST=$(kubectl get po -l istio=ingressgateway -n istio-system -o 'jsonpath={.items[0].status.hostIP}')
