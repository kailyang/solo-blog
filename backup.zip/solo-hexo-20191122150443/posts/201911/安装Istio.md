title: ' 安装Istio'
date: '2019-11-20 23:50:18'
updated: '2019-11-20 23:50:18'
tags: [微服务, Istio, 服务网格]
permalink: /articles/2019/11/20/1574265018078.html
---
![](https://img.hacpai.com/bing/20171114.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 前置知识：docker、K8s

参考资料：

[Kubernets入门]([https://funtl.com/zh/service-mesh-kubernetes/#%E6%A6%82%E8%BF%B0](https://funtl.com/zh/service-mesh-kubernetes/#概述))

[从Docker到Kubernetes进阶](https://www.qikqiak.com/k8s-book/)

## 准备Minikube

Minikube是一个快速搭建单节点Kubenetes集群的工具，我们通过安装最新版本的 Minikube，获取一个K8s集群，方便我们后续学习。

详细见[Minikube安装](https://juejin.im/post/5cefd07df265da1b725be735)

启动minikube的命令：

minikube start

如果需要翻墙：

minikube start --docker-env http_proxy=http://192.168.31.152:8123 --docker-env https_proxy=http://192.168.31.152:8123 --docker-env no_proxy=localhost,127.0.0.1,::1,192.168.31.0/24,192.168.99.0/24

## 安装 kubectl

准备Kubernetes 集群，操作该集群的话安装一个 kubectl 工具，方便我们后续操作

$ brew install kubernetes-cli  
...  
$ kubectl version  
Client Version: version.Info{Major:"1", Minor:"10", GitVersion:"v1.10.3", GitCommit:"2bba0127d85d5a46ab4b778548be28623b32d0b0", GitTreeState:"clean", BuildDate:"2018-05-21T09:17:39Z", GoVersion:"go1.9.3", Compiler:"gc", Platform:"darwin/amd64"}  
Server Version: version.Info{Major:"1", Minor:"10", GitVersion:"v1.10.3", GitCommit:"2bba0127d85d5a46ab4b778548be28623b32d0b0", GitTreeState:"clean", BuildDate:"2018-05-21T09:05:37Z", GoVersion:"go1.9.3", Compiler:"gc", Platform:"linux/amd64"}

注意 docker for mac 的 k8s 的 context 是 docker-for-desktop，如果目前已有其他集群环境，需要使用如下命令进行切换：

$ kubectl config use-context docker-for-desktop

kubectl 工具安装配置完成后，执行命令验证下是否可以正常操作集群：

$ kubectl get nodes  
NAME                 STATUS    ROLES     AGE       VERSION  
docker-for-desktop   Ready     master    3d        v1.10.3  
$ kubectl get pods -n kube-system  
NAME                                         READY     STATUS    RESTARTS   AGE  
etcd-docker-for-desktop                      1/1       Running   0          3d  
kube-apiserver-docker-for-desktop            1/1       Running   0          3d  
kube-controller-manager-docker-for-desktop   1/1       Running   0          3d  
kube-dns-86f4d74b45-ht885                    3/3       Running   1          3d  
kube-proxy-x7fnp                             1/1       Running   0          3d  
kube-scheduler-docker-for-desktop            1/1       Running   0          3d  
kubernetes-dashboard-7b9c7bc8c9-pmg97        1/1       Running   1          3d

能够正常看到上面的信息证明 Kubernetes 集群一切正常，也可以使用 kubectl 工具操作集群，这一步非常重要。

## 安装 kubernetes dashboard

直接下载官方推荐的 dashboard yaml 文件：

$ wget https://raw.githubusercontent.com/kubernetes/dashboard/master/src/deploy/recommended/kubernetes-dashboard.yaml  
--2018-09-19 10:17:36--  https://raw.githubusercontent.com/kubernetes/dashboard/master/src/deploy/recommended/kubernetes-dashboard.yaml  
Resolving raw.githubusercontent.com... 151.101.64.133, 151.101.128.133, 151.101.192.133, ...  
Connecting to raw.githubusercontent.com|151.101.64.133|:443... connected.  
HTTP request sent, awaiting response... 200 OK  
Length: 4582 (4.5K) [text/plain]  
Saving to: 'kubernetes-dashboard.yaml'  
​  
kubernetes-dashboard.yaml       100%[========================================================>]   4.47K  --.-KB/s   in 0s  
​  
2018-09-19 10:17:37 (22.8 MB/s) - 'kubernetes-dashboard.yaml' saved [4582/4582]

为了方便测试，我们将 kubernetes-dashboard.yaml 文件中 的 Service 改成 NodePort 类型的服务：

kind: Service  
apiVersion: v1  
metadata:  
 labels:  
 k8s-app: kubernetes-dashboard  
 name: kubernetes-dashboard  
 namespace: kube-system  
spec:  
 ports:  
 - port: 443  
 targetPort: 8443  
 type: NodePort  
 selector:  
 k8s-app: kubernetes-dashboard

还有一个需要注意的仍然是镜像的问题，默认使用的镜像地址是 k8s.gcr.io/kubernetes-dashboard-amd64 v1.10.0，如果没有科学上网，我们需要提前 pull 下来，然后重新打上该 tag，然后直接创建即可：

$ kubectl create -f kubernetes-dashboard.yaml  
...  
$ kubectl get svc -n kube-system  
NAME                   TYPE        CLUSTER-IP      EXTERNAL-IP   PORT(S)         AGE  
kube-dns               ClusterIP   10.96.0.10      <none>        53/UDP,53/TCP   3d  
kubernetes-dashboard   NodePort    10.100.61.38    <none>        443:30291/TCP   3d  
...

现在直接在浏览器中访问 [https://localhost:30291](https://localhost:30291/) 即可，记住一定要加上 **https**，在登录页面直接跳过权限验证即可：

  **k8s dashboard**

## 安装 Helm

istio 官方给出了几种安装的方式，手动通过 yaml 文件去安装也比较方便，但是还是需要忍受镜像翻墙的问题，我们这里使用官方更加推荐的 Helm 方式来进行安装，而且该方式涉及到的镜像都在 docker hub 上面，不需要翻墙就可以拉取。

首先安装 Helm 包管工具，可以参考官方文档安装即可：[https://istio.io/zh/docs/setup/kubernetes/helm-install/](https://istio.io/zh/docs/setup/kubernetes/helm-install/) ：

通过 包管理器安装 Helm 的客户端：

$ brew install kubernetes-helm
...
$ helm version
Client: &version.Version{SemVer:"v2.10.0", GitCommit:"9ad53aac42165a5fadc6c87be0dea6b115f93090", GitTreeState:"clean"}
Error: could not find tiller

安装完成后，需要初始化 Helm 对应的服务端程序 Tiller Server：

$ helm init

不过由于初始化的过程中同样需要使用到 gcr.io 的相关镜像和 chart 仓库，所以如果没有科学上网环境的话我们可以通过如下命令进行初始化：

$ helm init --upgrade --tiller-image cnych/tiller:v2.10.0 --stable-repo-url https://cnych.github.io/kube-charts-mirror/
$HELM_HOME has been configured at /root/.helm.

Tiller (the Helm server-side component) has been installed into your Kubernetes Cluster.

Please note: by default, Tiller is deployed with an insecure 'allow unauthenticated users' policy.
To prevent this, run `helm init` with the --tiller-tls-verify flag.
For more information on securing your installation see: https://docs.helm.sh/using_helm/#securing-your-helm-installation
Happy Helming!

另外我们还需要为 Tiller 创建一个 ServiceAccount，让他有权限去操作集群中的一些资源：

apiVersion: v1
kind: ServiceAccount
metadata:
  name: tiller
  namespace: kube-system
---
apiVersion: rbac.authorization.k8s.io/v1beta1
kind: ClusterRoleBinding
metadata:
  name: tiller
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: ClusterRole
  name: cluster-admin
subjects:
  - kind: ServiceAccount
    name: tiller
    namespace: kube-system

保存为 rbac.yaml 然后创建：

$ kubectl create rbac.yaml
serviceaccount "tiller" created
clusterrolebinding.rbac.authorization.k8s.io "tiller" created

创建了 tiller 的 ServceAccount 后还没完，因为我们的 Tiller 之前已经就部署成功了，而且是没有指定 ServiceAccount 的，所以我们需要给 Tiller 打上一个 ServiceAccount 的补丁：

$ kubectl patch deploy --namespace kube-system tiller-deploy -p '{"spec":{"template":{"spec":{"serviceAccount":"tiller"}}}}'

至此, Helm 客户端和服务端都配置完成了：

$ helm version
Client: &version.Version{SemVer:"v2.10.0", GitCommit:"9ad53aac42165a5fadc6c87be0dea6b115f93090", GitTreeState:"clean"}
Server: &version.Version{SemVer:"v2.10.0", GitCommit:"9ad53aac42165a5fadc6c87be0dea6b115f93090", GitTreeState:"clean"}

## 安装 istio

### 准备istio

在 istio 的 [github release 页面](https://github.com/istio/istio/releases/) 找到需要的istio版本，下载并解压缩：

curl -L https://github.com/istio/istio/releases/download/1.1.8/istio-1.1.8-linux.tar.gz | tar xz
mv istio-1.1.8/ $HOME/work/soft/istio/

修改`~/.bashrc`，加入以下内容：

# istio
export PATH="$PATH:/home/sky/work/soft/istio/bin"

执行`source ~/.bashrc`载入profile。

$ istioctl version  
Version: 1.0.8  
GitRevision: 11b640bb11593138a904f81e572d40e5e70b089b  
User: root@d76cad0a-8935-11e9-887b-0a580a2c0403  
Hub: docker.io/istio  
GolangVersion: go1.10.4  
BuildStatus: Clean

### 安装istio核心

先安装istio的CRD，日常验证用最简单的方式安装所有的crd：

# 1.1版本之前  
kubectl apply -f install/kubernetes/helm/istio/templates/crds.yaml  
​  
# 1.1版本之后  
for i in install/kubernetes/helm/istio-init/files/crd*yaml; do kubectl apply -f $i; done

简单起见，不做双向认证。

kubectl apply -f install/kubernetes/istio-demo.yaml

验证安装：

kubectl get svc -n istio-system  
kubectl get pods -n istio-system
